using System.Collections.Generic;

namespace AirlineReservationSystem
{
    class City
    {
        public string cityName { get; set; }
        public List<Airport> airports = new List<Airport>();
    }
}