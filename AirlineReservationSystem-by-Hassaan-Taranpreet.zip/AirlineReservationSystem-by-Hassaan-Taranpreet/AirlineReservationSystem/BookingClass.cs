﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystem
{
    class BookingClass
    {
        public string seatNumber { get; set; }
        public string bookingNumber { get; set; }
        public FlightClass Flight = new FlightClass();
        public PassengerClass Passenger = new PassengerClass();

        public void assignPassenger(ref PassengerClass p)
        {
            this.Passenger = p;
            var bookingClass = this;
            p.assignBooking(ref bookingClass);
            bookingClass = null;
        }

        public void assignFlight(ref FlightClass f)
        {
            this.Flight = f;
            var bookingClass = this;
            f.addBooking(ref bookingClass);
            bookingClass = null;
        }

        public void cancelBooking()
        {
            var bookingClass = this;
            this.Flight.cancelBooking(ref bookingClass);
            this.Passenger.removeBooking(ref bookingClass);
            Console.WriteLine("Booking # {0} has been cancelled successfully.",this.bookingNumber);
            bookingClass = null;
        }

        public void print()
        {
            var flightFlightNumber = this.Flight.flightNumber;
            if (flightFlightNumber != null)
                Console.WriteLine(
                    "Booking number: {0}\n" +
                    "Passenger Name: {1}\n" +
                    "Flight number: {2}\n" +
                    "Departure Airport: {3}\n" +
                    "Departure City: {4}\n" +
                    "Arrival Airport: {5}\n" +
                    "Arrival City: {6}\n" +
                    "Seat Number: {7}\n",
                    this.bookingNumber,
                    this.Passenger.Name,
                    flightFlightNumber,
                    this.Flight.departureAirport.airportName,
                    this.Flight.departureAirport.city.cityName,
                    this.Flight.arrivalAirport.airportName,
                    this.Flight.arrivalAirport.city.cityName,
                    this.seatNumber
                    );
            flightFlightNumber = null;
        }
    }
}
