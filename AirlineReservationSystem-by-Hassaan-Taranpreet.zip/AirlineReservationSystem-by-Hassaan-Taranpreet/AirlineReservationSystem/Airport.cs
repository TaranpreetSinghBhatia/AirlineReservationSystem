namespace AirlineReservationSystem
{
    class Airport
    {
        public string airportName { get; set; }
        public City city = new City();

        public void setAirportCity(City c)
        {
            city = c;
            c.airports.Add(this);
        }
    }
}