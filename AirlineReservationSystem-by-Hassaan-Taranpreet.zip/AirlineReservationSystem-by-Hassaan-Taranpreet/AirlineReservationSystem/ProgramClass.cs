﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AirlineReservationSystem
{
    class ProgramClass
    {

        static void Main(string[] args)
        {
            // ******** This program is written by Hassaan Siddiqui & Taranpreet Singh **********
            
            AirlineClass concordiaAirlines = new AirlineClass();
            City city1 = new City()
            {
                cityName="Montreal",

            };
            City city2 = new City()
            {
                cityName = "Toronto",

            };
            
            Airport trudeauAirport = new Airport()
            {
                airportName = "Trudeau International Airport"
            };
            trudeauAirport.setAirportCity(city1);

            Airport MTLAirport = new Airport()
            {
                airportName = "Mirabel Airport"
            };
            MTLAirport.setAirportCity(city1);

            Airport TorontoAirport = new Airport()
            {
                airportName = "Toronto International Airport"
            };
            TorontoAirport.setAirportCity(city2);

            Airport trnAirport = new Airport()
            {
                airportName = "TRN Island Airport"
            };
            trnAirport.setAirportCity(city2);

            FlightClass Flight1 = new FlightClass()
            {
                flightNumber = "CA123",
                departureDate = new DateTime(2020, 12, 25),
                arrivalDate = new DateTime(2020, 12, 25),
                departureTime = Convert.ToDateTime("10:15"),
                actualDepartureTime = Convert.ToDateTime("10:45"),
                arrivalTime = Convert.ToDateTime("12:30"),
                actualArrivalTime = Convert.ToDateTime("13:15"),
                departureAirport = TorontoAirport,
                arrivalAirport = trudeauAirport
            };
            Flight1.setDuration();
            Flight1.calculateArrivalDelay();
            Flight1.calculateDepartureDelay();
            concordiaAirlines.setFlight(ref Flight1);

            FlightClass Flight2 = new FlightClass()
            {
                flightNumber = "CA345",
                departureDate = new DateTime(2020, 04, 15),
                arrivalDate = new DateTime(2020, 04, 15),
                departureTime = Convert.ToDateTime("11:15"),
                actualDepartureTime = Convert.ToDateTime("11:45"),
                arrivalTime = Convert.ToDateTime("13:30"),
                actualArrivalTime = Convert.ToDateTime("14:05"),
                arrivalAirport = MTLAirport,
                departureAirport = TorontoAirport
            };
            Flight2.setDuration();
            Flight2.calculateArrivalDelay();
            Flight2.calculateDepartureDelay();
            concordiaAirlines.setFlight(ref Flight2);

            FlightClass Flight3 = new FlightClass()
            {
                flightNumber = "CA456",
                departureDate = new DateTime(2020, 05, 25),
                arrivalDate = new DateTime(2020, 05, 25),
                departureTime = Convert.ToDateTime("13:15"),
                actualDepartureTime = Convert.ToDateTime("13:42"),
                arrivalTime = Convert.ToDateTime("16:30"),
                actualArrivalTime = Convert.ToDateTime("17:15"),
                arrivalAirport = MTLAirport,
                departureAirport = trnAirport
            };
            Flight3.setDuration();
            Flight3.calculateArrivalDelay();
            Flight3.calculateDepartureDelay();
            concordiaAirlines.setFlight(ref Flight3);

            PassengerClass passenger = new PassengerClass()//creating passenger object
            {
                Address = "111 Building, Rue Bishop, Montreal",
                Name = "John Claude",
                Tel = "5145145141",
                Email = "john.c@mail.ca",
                luggageAllowed = true,
                numberOfBags = 2,
                PassportNumber = "ABC1234"
            };

            PassengerClass passenger1 = new PassengerClass()
            {

                Name = "Sourabh Surush",
                Tel = "5145674433",
                Email = "sourabh@mail.ca",
                Address = "123 Street 5th, Edmonton",
                luggageAllowed = true,
                numberOfBags = 1,
                PassportNumber = "DEF1234"

            };
            
            PassengerClass passenger2 = new PassengerClass()
            {

                Name = "Shaili Chishti",
                Tel = "613223340",
                Email = "shaili@mail.ca",
                Address = "432 9th Avenue, Ottawa",
                luggageAllowed = true,
                numberOfBags = 2,
                PassportNumber = "FGH1234"
            };
            
            PassengerClass passenger3 = new PassengerClass()
            {

                Name = "Saloni Claude",
                Tel = "5141908787",
                Email = "Saloni@mail.ca",
                Address = "23 Rue Mackay, Montreal",
                luggageAllowed = false,
                PassportNumber = "HJG1234"
            };

            EmployeeClass crew1 = new EmployeeClass()
            {
                Name = "Chaman Kaur",
                Tel = "5145311234",
                IsManager = false,
                Email = "chaman@mail.ca"
            };
            concordiaAirlines.setEmployee(ref crew1);

            EmployeeClass crew2 = new EmployeeClass()
            {
                Name = "Taran Singh",
                Tel = "5145321334",
                IsManager = false,
                Email = "taran.s@mail.ca"
            };
            concordiaAirlines.setEmployee(ref crew2);

            EmployeeClass crew3 = new EmployeeClass()
            {
                Name = "Shaman Rajput",
                Tel = "55002350",
                Email = "shaman@mail.ca",
                Address = "123 Rue Catherine, Montreal",
                IsManager = false
            };
            concordiaAirlines.setEmployee(ref crew3);

            EmployeeClass crew4 = new EmployeeClass()
            {
                Name = "Shona",
                Tel = "55002350",
                Email = "Shona@xyz.ca",
                Address = "123 xyz qwe",
                IsManager = false
            };
            concordiaAirlines.setEmployee(ref crew4);

            EmployeeClass crew5 = new EmployeeClass();
            crew5.Name = "Saman";
            crew5.Tel = "55002350";
            crew5.Email = "Saman@xyz.ca";
            crew5.Address = "123 xyz qwe";
            crew5.IsManager = false;
            concordiaAirlines.setEmployee(ref crew5);

            EmployeeClass crew6 = new EmployeeClass();
            crew6.Name = "Saam";
            crew6.Tel = "55002350";
            crew6.Email = "Saam@xyz.ca";
            crew6.Address = "123 xyz qwe";
            crew6.IsManager = false;
            concordiaAirlines.setEmployee(ref crew6);

            EmployeeClass Manager1 = new EmployeeClass();
            Manager1.Name = "Michael Tremblay";
            Manager1.Tel = "55002350";
            Manager1.Email = "mick@mail.ca";
            Manager1.Address = "123 xyz qwe";
            Manager1.IsManager = true;
            concordiaAirlines.setEmployee(ref Manager1);

            EmployeeClass Manager2 = new EmployeeClass();
            Manager2.Name = "Chris Singh";
            Manager2.Tel = "55002350";
            Manager2.Email = "chris@mail.ca";
            Manager2.Address = "123 xyz qwe";
            Manager2.IsManager = true;
            concordiaAirlines.setEmployee(ref Manager2);

            EmployeeClass Manager3 = new EmployeeClass();
            Manager3.Name = "Eric Demers";
            Manager3.Tel = "55002350";
            Manager3.Email = "eric@mail.ca";
            Manager3.Address = "123 xyz qwe";
            Manager3.IsManager = true;
            concordiaAirlines.setEmployee(ref Manager3);

            //Declaration ends

            Console.WriteLine("***** Welcome to " + concordiaAirlines.Name + " *****");
            Console.WriteLine("This program is a Flight reservation management system, developed by Hassaan Siddiqui and Taranpreet Singh.");
            Console.WriteLine("Airline has total {0} employees.",concordiaAirlines.allEmployees.Count);
            Console.WriteLine("Airline has total {0} flights.\n",concordiaAirlines.allflights.Count);

            //Adding Employees to Flight 1
            Flight1.employee = new List<EmployeeClass>();
            Flight1.assignCrew(crew1);
            Flight1.assignCrew(crew2);
            Flight1.assignCrew(Manager1);
            Console.WriteLine("***** Details of 1st flight:");
            Flight1.print();            

            //Adding Employees to Flight 2
            Flight2.employee = new List<EmployeeClass>();
            Flight2.assignCrew(crew3);
            Flight2.assignCrew(crew4);
            Flight2.assignCrew(Manager2);
            Console.WriteLine("***** Details of 2nd flight");
            Flight2.print();

            //Adding Employees to Flight 3
            Flight3.employee = new List<EmployeeClass>();
            Flight3.assignCrew(crew5);
            Flight3.assignCrew(crew6);
            Flight3.assignCrew(Manager3);
            Console.WriteLine("***** Details of 3rd flight");
            Flight3.print();

            //Bookings 
            BookingClass booking1 = new BookingClass();
            booking1.assignPassenger(ref passenger);
            booking1.seatNumber = "C15";
            booking1.bookingNumber = "BK1001";
            booking1.assignFlight(ref Flight1);


            BookingClass booking2 = new BookingClass();
            booking2.assignPassenger(ref passenger1);
            booking2.seatNumber = "C20";
            booking2.bookingNumber = "BK1002";
            booking2.assignFlight(ref Flight1);

            BookingClass booking3 = new BookingClass();
            booking3.assignPassenger(ref passenger2);
            booking3.seatNumber = "C25";
            booking3.bookingNumber = "BK1003";
            booking3.assignFlight(ref Flight1);

            BookingClass booking4 = new BookingClass();
            booking4.assignPassenger(ref passenger3);
            booking4.seatNumber = "C35";
            booking4.bookingNumber = "BK1004";
            booking4.assignFlight(ref Flight2);


            BookingClass booking5 = new BookingClass();
            booking5.assignPassenger(ref passenger1);
            booking5.seatNumber = "C30";
            booking5.bookingNumber = "BK1005";
            booking5.assignFlight(ref Flight2);

            BookingClass booking6 = new BookingClass();
            booking6.assignPassenger(ref passenger2);
            booking6.seatNumber = "C45";
            booking6.bookingNumber = "BK1006";
            booking6.assignFlight(ref Flight3);

            BookingClass booking7 = new BookingClass();
            booking7.assignPassenger(ref passenger3);
            booking7.seatNumber = "C55";
            booking7.bookingNumber = "BK1007";
            booking7.assignFlight(ref Flight3);

            
            Console.WriteLine("********** Below are all the bookings.\n");

            booking1.print();
            booking2.print();
            booking3.print();
            booking4.print();
            booking5.print();
            booking6.print();
            booking7.print();

            Console.WriteLine("******** Bookings per flight:");
            Console.WriteLine("Flight # " + Flight1.flightNumber + " has " + Flight1.bookings.Count + " booking(s).");
            Console.WriteLine("Flight # " + Flight2.flightNumber + " has " + Flight2.bookings.Count + " booking(s).");
            Console.WriteLine("Flight # " + Flight3.flightNumber + " has " + Flight3.bookings.Count + " booking(s).");
            
            Console.WriteLine("\n*********** Cities information:");
            Console.WriteLine("City of " + city1.cityName + " has " + city1.airports.Count + " airports.");
            Console.WriteLine("City of " + city2.cityName + " has " + city2.airports.Count + " airports.");
            
            Console.WriteLine("\n*********** Flight Delays are as below:");
            Console.WriteLine("Departure Delay of " + Flight1.flightNumber + " is " + Flight1.arrivalDelay + " hours");
            Console.WriteLine("Arrival Delay of " + Flight1.flightNumber + " is " + Flight1.departureDelay + " hours");
            Console.WriteLine("Departure Delay of " + Flight2.flightNumber + " is " + Flight2.arrivalDelay + " hours");
            Console.WriteLine("Arrival Delay of " + Flight2.flightNumber + " is " + Flight2.departureDelay + " hours");
            Console.WriteLine("Departure Delay of " + Flight3.flightNumber + " is " + Flight3.arrivalDelay + " hours");
            Console.WriteLine("Arrival Delay of " + Flight3.flightNumber + " is " + Flight3.departureDelay + " hours");

            Console.WriteLine("************* Cancelling bookings:");

            booking7.cancelBooking();
            Console.WriteLine("Now Flight # " + Flight3.flightNumber + " has " + Flight3.bookings.Count + " booking(s).\n");
            booking7 = null;

            Flight3.cancelAllBookings();
            concordiaAirlines.removeFlight(ref Flight3);
            Flight3 = null;

            Console.WriteLine("\n\n***** Program completed. Press any key to exit program. *****");
            Console.ReadLine();
            return;
        }
    }
}
