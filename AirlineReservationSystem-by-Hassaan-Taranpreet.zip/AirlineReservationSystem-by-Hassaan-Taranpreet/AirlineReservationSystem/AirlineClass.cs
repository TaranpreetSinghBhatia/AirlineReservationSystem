﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AirlineReservationSystem
{
    class AirlineClass
    {
        public string Name { get; } = "Concordia Airlines";
        public List<FlightClass> allflights = new List<FlightClass>();
        public List<EmployeeClass> allEmployees = new List<EmployeeClass>();

        public void setEmployee(ref EmployeeClass e)
        {
            this.allEmployees.Add(e);
            e.airline = this;
        }

        public void setFlight(ref FlightClass f)
        {
            this.allflights.Add(f);
            f.airline = this;
        }

        public void removeFlight(ref FlightClass f)
        {
            this.allflights.Remove(f);
            Console.WriteLine("Flight {0} has been cancelled. Airline has total {1} flights now.",f.flightNumber,this.allflights.Count);
        }
        
    }
}
