﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace AirlineReservationSystem
{
    class PassengerClass : PersonClass
    {
        private string passportNumber;
        public string PassportNumber
        {
            get => passportNumber;
            set => passportNumber = value;
        }
        public bool luggageAllowed { get; set; }
        public int numberOfBags { get; set; }
        public List<BookingClass> bookings = new List<BookingClass>();

        public void assignBooking(ref BookingClass b)
        {
            this.bookings.Add(b);
        }

        public void removeBooking(ref BookingClass b)
        {
            this.bookings.Remove(b);
        }

        /*public void passenger()
        {
            FlightClass flights = new FlightClass();
            Console.WriteLine("please type your name");
            string passengerName = Console.ReadLine();
            Console.WriteLine("Hi {0}", passengerName);
            Thread.Sleep(1000);

            Console.WriteLine("please select flight from below menu");
            flights.selectFlight();
            
        }*/
    }
}
