﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace AirlineReservationSystem
{
    class EmployeeClass : PersonClass
    {
        public AirlineClass airline = new AirlineClass();
        private bool isManager; // field
        public bool IsManager   // property
        {
            get { return isManager; }
            set { isManager = value; }
        }
        public List<FlightClass> flight = new List<FlightClass>();

        public void assignFlight(FlightClass f)
        {
            this.flight.Add(f);
        }

        public void removeFlight(FlightClass f)
        {
            this.flight.Remove(f);
        }
    }
}
