﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystem
{
    class FlightClass

    {
        public string flightNumber { get; set; }
        public DateTime departureDate { get; set; }
        public DateTime departureTime { get; set; }
        public DateTime actualDepartureTime { get; set; }
        public DateTime arrivalDate { get; set; }
        public DateTime arrivalTime { get; set; }
        public DateTime actualArrivalTime { get; set; }
        public TimeSpan duration;
        public TimeSpan departureDelay;
        public TimeSpan arrivalDelay;
        public List<EmployeeClass> employee = new List<EmployeeClass>();
        public List<BookingClass> bookings = new List<BookingClass>();
        public AirlineClass airline = new AirlineClass();
        public Airport departureAirport = new Airport();
        public Airport arrivalAirport = new Airport();

        // ******** Functions below **********
        
        public void print()
        {
            Console.WriteLine("Flight Number is " + this.flightNumber);
            Console.WriteLine("Departure Time is {0}/{1}/{2} at {3}:{4} ",this.departureDate.Day,this.departureDate.Month,this.departureDate.Year,this.departureTime.Hour,this.departureTime.Minute);
            Console.WriteLine("Departure Airport is {0} in {1}",this.departureAirport.airportName,this.departureAirport.city.cityName);
            Console.WriteLine("Arrival Time is {0}/{1}/{2} at {3}:{4} ",this.arrivalDate.Day,this.arrivalDate.Month,this.arrivalDate.Year,this.arrivalTime.Hour,this.arrivalTime.Minute);
            Console.WriteLine("Arrival Airport is {0} in {1}",this.arrivalAirport.airportName,this.arrivalAirport.city.cityName);
            Console.WriteLine("Flight duration is " + this.duration);
            Console.WriteLine("Flight has " + this.employee.Count + " crew members.\nCrew Members are:\n");
            foreach (EmployeeClass c in this.employee)
            {
                Console.WriteLine("Name={0}, Telephone={1}, Email={2}", c.Name, c.Tel, c.Email);
                if (c.IsManager)
                {
                    Console.WriteLine(c.Name + " is a Supervisor\n");
                }
                else
                {
                    Console.WriteLine(c.Name + " is a Crew Member\n");
                }
            }
        }

        public void addBooking(ref BookingClass b)
        {
            bookings.Add(b);
        }

        public void cancelBooking(ref BookingClass b)
        {
            bookings.Remove(b);
        }

        public void cancelAllBookings()
        {
            bookings.Clear();
            foreach (EmployeeClass e in this.employee)
            {
                e.removeFlight(this);
            }

            foreach (BookingClass b in this.bookings)
            {
                b.cancelBooking();
            }
            Console.WriteLine("All bookings for Flight # {0} have been cancelled successfully.",this.flightNumber);
        }

        public void assignCrew(EmployeeClass e)
        {
            this.employee.Add(e);
            e.assignFlight(this);
        }
        
        public void calculateArrivalDelay()
        {
            this.arrivalDelay = this.actualArrivalTime - this.arrivalTime;
        }

        public void calculateDepartureDelay()
        {
            this.departureDelay = this.actualDepartureTime - this.departureTime;
        }

        public void setDuration()
        {
            this.duration = this.arrivalTime - this.departureTime;
        }
        
    }
}
